$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$build = Join-Path $root 'build-windows'
$dist = Join-Path $root 'dist\windows-x64'

cmake -S $root -B $build -A x64
cmake --build $build --config Release --parallel
cmake --install $build --config Release --prefix $dist --component keyboardmania

$zip = Join-Path $root 'dist\keyboardmania-midi-bridge-windows-x64.zip'
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip }
Compress-Archive -LiteralPath "$dist\keyboardmania-midi-bridge.exe","$dist\README-ja.md","$dist\README.md","$dist\LICENSE" -DestinationPath $zip
Write-Host "Created: $zip"
