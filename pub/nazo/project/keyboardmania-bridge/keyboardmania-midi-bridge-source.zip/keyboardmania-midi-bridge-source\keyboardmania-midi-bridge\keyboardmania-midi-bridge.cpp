#include <hidapi.h>
#include <RtMidi.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#include <conio.h>
#else
#include <cerrno>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#endif

namespace {

constexpr unsigned short kVendorId = 0x0507;
constexpr unsigned short kProductId = 0x0010;
constexpr std::size_t kReportSize = 8;
constexpr int kMaxString = 255;

std::atomic<int> pitchShift{0};
std::atomic<bool> shouldExit{false};

struct KeyMapping {
  unsigned char byteIndex;
  unsigned char mask;
  const char* name;
};

constexpr KeyMapping kKeyMappings[] = {
    {1, 0x40, "Select"}, {2, 0x40, "Start"},
    {3, 0x20, "Whl-Up"}, {3, 0x40, "Whl-Dn"},
    {0, 0x01, "C3"}, {0, 0x02, "C#3"}, {0, 0x04, "D3"},
    {0, 0x08, "D#3"}, {0, 0x10, "E3"}, {0, 0x20, "F3"},
    {0, 0x40, "F#3"}, {1, 0x01, "G3"}, {1, 0x02, "G#3"},
    {1, 0x04, "A3"}, {1, 0x08, "A#3"}, {1, 0x10, "B3"},
    {1, 0x20, "C4"}, {2, 0x01, "C#4"}, {2, 0x02, "D4"},
    {2, 0x04, "D#4"}, {2, 0x08, "E4"}, {2, 0x10, "F4"},
    {2, 0x20, "F#4"}, {3, 0x01, "G4"}, {3, 0x02, "G#4"},
    {3, 0x04, "A4"}, {3, 0x08, "A#4"}, {3, 0x10, "B4"},
};

const std::map<std::uint32_t, std::uint8_t> kNoteMappings = {
    {0x00400000, 0},  {0x00004000, 1},  {0x00000020, 2},
    {0x00000040, 3},  {0x01000000, 48}, {0x02000000, 49},
    {0x04000000, 50}, {0x08000000, 51}, {0x10000000, 52},
    {0x20000000, 53}, {0x40000000, 54}, {0x00010000, 55},
    {0x00020000, 56}, {0x00040000, 57}, {0x00080000, 58},
    {0x00100000, 59}, {0x00200000, 60}, {0x00000100, 61},
    {0x00000200, 62}, {0x00000400, 63}, {0x00000800, 64},
    {0x00001000, 65}, {0x00002000, 66}, {0x00000001, 67},
    {0x00000002, 68}, {0x00000004, 69}, {0x00000008, 70},
    {0x00000010, 71},
};

void sleepFor(std::chrono::milliseconds duration) {
  std::this_thread::sleep_for(duration);
}

void changeOctave(int direction) {
  int current = pitchShift.load();
  const int next = current + direction;
  if (next < -4 || next > 4) {
    std::printf("Cannot shift %s\n", direction < 0 ? "lower" : "higher");
    return;
  }
  pitchShift.store(next);
  std::printf("Pitch shift: %+d octave(s)\n", next);
}

void handleConsoleKey(int key) {
  if (key == 'q' || key == 'Q') {
    std::printf("Exiting...\n");
    shouldExit.store(true);
  } else if (key == '-') {
    pitchShift.store(0);
    std::printf("Pitch reset to default\n");
  } else if (key == 1001) {
    changeOctave(-1);
  } else if (key == 1002) {
    changeOctave(1);
  }
}

#ifdef _WIN32
void consoleReader() {
  std::printf("[Left/Right: octave, '-': reset, 'q': quit]\n");
  while (!shouldExit.load()) {
    if (!_kbhit()) {
      sleepFor(std::chrono::milliseconds(50));
      continue;
    }
    int key = _getch();
    if (key == 0 || key == 224) {
      key = _getch();
      if (key == 75) handleConsoleKey(1001);
      if (key == 77) handleConsoleKey(1002);
    } else {
      handleConsoleKey(key);
    }
  }
}
#else
class TerminalRawMode {
 public:
  TerminalRawMode() {
    active_ = isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &original_) == 0;
    if (!active_) return;
    termios raw = original_;
    raw.c_lflag &= static_cast<tcflag_t>(~(ICANON | ECHO));
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 0;
    active_ = tcsetattr(STDIN_FILENO, TCSANOW, &raw) == 0;
  }
  ~TerminalRawMode() {
    if (active_) tcsetattr(STDIN_FILENO, TCSANOW, &original_);
  }

 private:
  termios original_{};
  bool active_ = false;
};

void consoleReader() {
  TerminalRawMode terminal;
  std::printf("[Left/Right: octave, '-': reset, 'q': quit]\n");
  while (!shouldExit.load()) {
    fd_set readSet;
    FD_ZERO(&readSet);
    FD_SET(STDIN_FILENO, &readSet);
    timeval timeout{0, 50000};
    const int ready = select(STDIN_FILENO + 1, &readSet, nullptr, nullptr, &timeout);
    if (ready <= 0) continue;

    unsigned char keys[3] = {};
    const ssize_t count = read(STDIN_FILENO, keys, sizeof(keys));
    if (count == 0) return;
    if (count == 3 && keys[0] == 27 && keys[1] == '[') {
      if (keys[2] == 'D') handleConsoleKey(1001);
      if (keys[2] == 'C') handleConsoleKey(1002);
    } else if (count > 0) {
      handleConsoleKey(keys[0]);
    }
  }
}
#endif

void printPressedKeys(const unsigned char* buffer) {
  std::printf("[ ");
  for (const auto& mapping : kKeyMappings) {
    if (buffer[mapping.byteIndex] & mapping.mask) std::printf("%s ", mapping.name);
  }
  std::printf("]\n");
}

std::uint32_t readState(const unsigned char* buffer) {
  return (static_cast<std::uint32_t>(buffer[0]) << 24) |
         (static_cast<std::uint32_t>(buffer[1]) << 16) |
         (static_cast<std::uint32_t>(buffer[2]) << 8) |
         static_cast<std::uint32_t>(buffer[3]);
}

void rotateLeft(unsigned char* buffer, std::size_t size) {
  if (size == 0) return;
  const unsigned char first = buffer[0];
  std::memmove(buffer, buffer + 1, size - 1);
  buffer[size - 1] = first;
}

bool openMidiPort(RtMidiOut& midiOut) {
  while (!shouldExit.load()) {
    const unsigned int count = midiOut.getPortCount();
    if (count == 0) {
#ifdef __APPLE__
      midiOut.openVirtualPort("Keyboardmania");
      std::printf("Created virtual MIDI port: Keyboardmania\n");
      return true;
#else
      std::printf("No MIDI ports available. Start loopMIDI, then waiting...\n");
      sleepFor(std::chrono::seconds(1));
      continue;
#endif
    }

    std::printf("\nAvailable MIDI ports:\n");
    for (unsigned int i = 0; i < count; ++i) {
      std::printf("  [%u] %s\n", i, midiOut.getPortName(i).c_str());
    }

    std::printf("\nEnter MIDI port number: ");
    std::fflush(stdout);
    std::string input;
    if (!std::getline(std::cin, input)) return false;
    try {
      std::size_t parsed = 0;
      const int selected = std::stoi(input, &parsed);
      if (parsed == input.size() && selected >= 0 &&
          selected < static_cast<int>(count)) {
        const std::string name = midiOut.getPortName(selected);
        midiOut.openPort(selected);
        std::printf("Opened %s\n", name.c_str());
        return true;
      }
    } catch (...) {
    }
    std::printf("Invalid selection.\n");
  }
  return false;
}

void printDeviceString(hid_device* device, const char* label,
                       int (*getter)(hid_device*, wchar_t*, std::size_t)) {
  wchar_t value[kMaxString] = {};
  if (getter(device, value, kMaxString) == 0)
    std::wprintf(L"%hs: %ls\n", label, value);
}

int runBridge(bool verbose) {
  std::printf("Looking for Keyboardmania controller (0507:0010)...\n");
  if (hid_init() != 0) {
    std::fprintf(stderr, "Could not initialize HIDAPI.\n");
    return 1;
  }

  hid_device* rawDevice = nullptr;
  while (!shouldExit.load() && rawDevice == nullptr) {
    rawDevice = hid_open(kVendorId, kProductId, nullptr);
    if (!rawDevice) sleepFor(std::chrono::seconds(1));
  }
  if (shouldExit.load()) {
    hid_exit();
    return 0;
  }

  std::unique_ptr<hid_device, decltype(&hid_close)> device(rawDevice, &hid_close);
  printDeviceString(device.get(), "Manufacturer", hid_get_manufacturer_string);
  printDeviceString(device.get(), "Product", hid_get_product_string);
  printDeviceString(device.get(), "Serial", hid_get_serial_number_string);

  try {
    RtMidiOut midiOut;
    if (!openMidiPort(midiOut)) {
      hid_exit();
      return 1;
    }

    std::printf("Ready...\n");
    std::uint32_t previousState = 0;
    std::thread readerThread(consoleReader);
    unsigned char buffer[kReportSize] = {};

    while (!shouldExit.load()) {
      const int result = hid_read_timeout(device.get(), buffer, sizeof(buffer), 100);
      if (result < 0) {
        std::printf("Controller disconnected; waiting for reconnection...\n");
        shouldExit.store(true);
        break;
      }
      if (result < 5) continue;

      rotateLeft(buffer, static_cast<std::size_t>(result));
      if (verbose) printPressedKeys(buffer);
      const std::uint32_t state = readState(buffer);

      for (const auto& mapping : kNoteMappings) {
        const std::uint32_t mask = mapping.first;
        const std::uint8_t mappedValue = mapping.second;
        const bool isControl = mappedValue < 5;
        int midiValue = mappedValue;
        if (!isControl) midiValue += pitchShift.load() * 12;

        if ((state & mask) && !(previousState & mask)) {
          const std::vector<unsigned char> message = {
              static_cast<unsigned char>(isControl ? 0xB0 : 0x90),
              static_cast<unsigned char>(midiValue), 64};
          midiOut.sendMessage(&message);
        } else if (!isControl && !(state & mask) && (previousState & mask)) {
          const std::vector<unsigned char> message = {
              0x80, static_cast<unsigned char>(midiValue), 64};
          midiOut.sendMessage(&message);
        }
      }
      previousState = state;
    }

    shouldExit.store(true);
    readerThread.join();
    if (midiOut.isPortOpen()) midiOut.closePort();
  } catch (const RtMidiError& error) {
    std::fprintf(stderr, "MIDI error: %s\n", error.what());
    hid_exit();
    return 1;
  }

  device.reset();
  hid_exit();
  return 0;
}

void printUsage(const char* executable) {
  std::printf("Usage: %s [-v|--verbose]\n", executable);
}

}  // namespace

int main(int argc, char* argv[]) {
  bool verbose = false;
  for (int i = 1; i < argc; ++i) {
    if (std::strcmp(argv[i], "-v") == 0 ||
        std::strcmp(argv[i], "--verbose") == 0) {
      verbose = true;
    } else if (std::strcmp(argv[i], "-h") == 0 ||
               std::strcmp(argv[i], "--help") == 0) {
      printUsage(argv[0]);
      return 0;
    } else {
      std::fprintf(stderr, "Unknown argument: %s\n", argv[i]);
      printUsage(argv[0]);
      return 1;
    }
  }

  return runBridge(verbose);
}
