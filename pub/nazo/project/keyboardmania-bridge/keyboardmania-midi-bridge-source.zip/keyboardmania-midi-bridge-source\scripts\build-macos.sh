#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
BUILD="$ROOT/build-macos"
DIST="$ROOT/dist/macos-universal"

cmake -S "$ROOT" -B "$BUILD" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
cmake --build "$BUILD" --parallel
cmake --install "$BUILD" --prefix "$DIST" --component keyboardmania

codesign --force --sign - "$DIST/keyboardmania-midi-bridge"
ditto -c -k --sequesterRsrc --keepParent "$DIST" \
  "$ROOT/dist/keyboardmania-midi-bridge-macos-universal.zip"
echo "Created: $ROOT/dist/keyboardmania-midi-bridge-macos-universal.zip"
