# Keyboardmania MIDI Bridge

PlayStation 2用の **Keyboardmania専用コントローラー（RU025）** を、
パソコンのMIDIキーボードとして使うためのソフトです。

難しい設定はほとんどありません。  
自分のパソコンに合ったZIPを展開して、以下の順番で準備してください。

## 最初に確認するもの

- Keyboardmania専用USBコントローラー（型番: RU025）
- Windows 10／11、またはmacOS 11以降のパソコン
- 音を鳴らすDAWや音楽ソフト

このソフト自体にはピアノなどの音源は入っていません。  
コントローラーの入力をMIDI信号へ変換し、DAWへ渡す役目です。

---

## Windowsで使う

### 1. ZIPを展開する

`keyboardmania-midi-bridge-windows-x64.zip` を右クリックして、
「すべて展開」を選びます。

ZIPの中から直接起動せず、必ず展開したフォルダーを使ってください。

### 2. loopMIDIを準備する

Windowsでは、MIDI信号の受け渡しに
[loopMIDI](https://www.tobias-erichsen.de/software/loopmidi.html) を使用します。

1. loopMIDIをインストールして起動します。
2. `New port-name` に `Keyboardmania` と入力します。
3. 左下の `＋` ボタンを押して、MIDIポートを作ります。
4. loopMIDIは終了せず、そのまま起動しておきます。

### 3. コントローラーとBridgeを起動する

1. KeyboardmaniaコントローラーをUSB接続します。
2. `keyboardmania-midi-bridge.exe` をダブルクリックします。
3. Windowsの警告が出た場合は「詳細情報」→「実行」を選びます。
4. 黒い画面に、次のようなMIDIポート一覧が表示されます。

   ```text
   Available MIDI ports:
     [0] Keyboardmania

   Enter MIDI port number:
   ```

5. `Keyboardmania` の左に表示された番号を入力して、Enterを押します。
6. `Ready...` と表示されたら準備完了です。

番号は環境によって変わります。上の例では `0` ですが、
実際の画面に表示された番号を入力してください。

### 4. DAWで音を鳴らす

1. DAWや音楽ソフトを起動します。
2. MIDI入力デバイスとして `Keyboardmania` を選びます。
3. ピアノやシンセなど、好きなソフト音源をトラックに設定します。
4. 必要に応じて、トラックの録音待機や入力モニターをオンにします。
5. コントローラーの鍵盤を押して音が鳴れば成功です。

---

## Macで使う

### 1. ZIPを展開する

`keyboardmania-midi-bridge-macos-universal.zip` をダブルクリックして展開します。
Apple Silicon搭載MacとIntel Macの両方で使えます。

### 2. 初回だけターミナルから起動する

macOSでは、インターネットから取得した未公証アプリの実行を止めることがあります。
初回だけ「ターミナル」を開き、展開したフォルダーへ移動して次を実行します。

```sh
xattr -dr com.apple.quarantine keyboardmania-midi-bridge
chmod +x keyboardmania-midi-bridge
./keyboardmania-midi-bridge
```

macOSの確認画面が出た場合は、
「システム設定」→「プライバシーとセキュリティ」から
「このまま開く」を選んでください。

### 3. コントローラーとDAWをつなぐ

1. KeyboardmaniaコントローラーをUSB接続します。
2. Bridgeを起動します。
3. 使用できるMIDI出力先がある場合は、その番号を入力してEnterを押します。
4. 出力先がない場合は、`Keyboardmania` という仮想MIDIポートが自動作成されます。
5. DAW側のMIDI入力で `Keyboardmania` を選びます。
6. ソフト音源を設定し、鍵盤を押して音が鳴ることを確認します。

---

## Bridgeの操作

Bridgeの黒い画面を選択した状態で、次のキーを押します。

| キー | 動作 |
|---|---|
| `←` | 1オクターブ下げる |
| `→` | 1オクターブ上げる |
| `-` | 元の音域へ戻す |
| `q` | Bridgeを終了する |

オクターブは上下それぞれ4段階まで変更できます。

コントローラーのSelect、Start、ホイール操作はMIDIコントロール信号として送られます。
DAW側のMIDI Learn機能などを使って、好きな操作へ割り当てられます。

## 入力を確認したいとき

鍵盤やボタンが認識されているか詳しく確認するには、
ターミナルまたはPowerShellから `-v` を付けて起動します。

Windows:

```powershell
.\keyboardmania-midi-bridge.exe -v
```

macOS:

```sh
./keyboardmania-midi-bridge -v
```

押されている鍵盤名が黒い画面に表示されます。

---

## うまく動かないとき

### `Looking for Keyboardmania controller...` のまま進まない

- コントローラーのUSBを一度抜き、数秒待ってから挿し直してください。
- USBハブを使わず、パソコン本体のUSBポートへ直接接続してみてください。
- パソコンをスリープさせた後は認識されないことがあります。抜き差しで直らない場合は再起動してください。
- 対応機種はRU025（USB ID: `0507:0010`）です。

### Windowsで `No MIDI ports available` と表示される

- loopMIDIが起動しているか確認してください。
- loopMIDIに `Keyboardmania` ポートを作ったか確認してください。
- loopMIDIを起動してから、Bridgeを起動し直してください。

### `Ready...` と表示されるのに音が鳴らない

- DAWのMIDI入力が `Keyboardmania` になっているか確認してください。
- ソフト音源がトラックに設定されているか確認してください。
- トラックの録音待機または入力モニターをオンにしてください。
- loopMIDIとBridgeで同じポートを選んでいるか確認してください。
- `-v` を付けて起動し、鍵盤名が表示されるか確認してください。

### コントローラーを抜いたら止まった

安全のためBridgeも終了します。
コントローラーを接続し直してから、Bridgeをもう一度起動してください。

### Macで開けない

- 上記の `xattr` と `chmod` をもう一度実行してください。
- 「システム設定」→「プライバシーとセキュリティ」を確認してください。
- Bridgeを置いたフォルダーでターミナルを開いているか確認してください。

---

## 開発者向け：ソースからビルドする

通常の使用では、この作業は必要ありません。

依存ライブラリはCMakeが自動取得します。

Windows（Visual Studio 2022）:

```powershell
.\scripts\build-windows.ps1
```

macOS（Xcode Command Line ToolsとCMake）:

```sh
sh scripts/build-macos.sh
```

macOS版はApple Silicon／Intel対応のUniversal Binaryとして生成されます。

## 対応コントローラー

- 製品: PlayStation 2用 Keyboardmania Controller
- 型番: RU025
- Vendor ID: `0x0507`（Hosiden Corp.）
- Product ID: `0x0010`

このソフトは
[HIDAPI](https://github.com/libusb/hidapi) と
[RtMidi](https://github.com/thestk/rtmidi) を使用しています。
